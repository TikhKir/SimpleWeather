package com.example.simpleweather.local

interface DataApi {

}