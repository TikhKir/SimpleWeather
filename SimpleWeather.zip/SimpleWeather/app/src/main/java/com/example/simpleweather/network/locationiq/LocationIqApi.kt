package com.example.simpleweather.network.locationiq

interface LocationIqApi {
}