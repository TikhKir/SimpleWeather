package com.example.simpleweather.local.model

import androidx.room.*
import androidx.room.ForeignKey.CASCADE

@Entity(
    tableName = "hourly_weather_conditions",
    indices = [Index(value = ["timeStamp"], unique = true)],
    foreignKeys = [
        ForeignKey(
            entity = PlaceDB::class,
            parentColumns = ["placeId"],
            childColumns = ["placeParentId"],
            onDelete = CASCADE
        )
    ]
)
data class HourlyWeatherConditionDB(
    @PrimaryKey(autoGenerate = true)
    val hourlyConditionId: Int,

    val placeParentId: Int,
    val timeStamp: Int,

    val sunrise: Int?,
    val sunset: Int?,

    val tempDay: Float?,
    val tempEvening: Float?,
    val tempNight: Float?,
    val tempMorning: Float?,
    val tempMax: Float?,
    val tempMin: Float?,

    val tempDayFL: Float?,
    val tempEveningFL: Float?,
    val tempNightFL: Float?,
    val tempMorningFL: Float?,

    val pressure: Int?,
    val humidity: Int?,
    val dewPoint: Float?,
    val clouds: Int?,
    val windSpeed: Float?,
    val windDeg: Int?,

    val weatherId: Int?,
    val weatherName: String?,
    val weatherDescription: String?,
    val weatherIcon: String?,

    val probabilityOfPrecipitation: Float?,
    val snowVolume: Float?,
    val rainVolume: Float?,
    val uvi: Float?
)