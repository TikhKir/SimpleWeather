package com.example.simpleweather.network.openweather.rawmodel

import com.example.simpleweather.repository.model.HourlyWeatherCondition
import com.google.gson.annotations.SerializedName


data class RawHourly (
    @SerializedName("dt")
    val dt: Int,

    @SerializedName("temp")
    val temp: Float? = null,

    @SerializedName("feels_like")
    val feelsLike: Float? = null,

    @SerializedName("pressure")
    val pressure: Int? = null,

    @SerializedName("humidity")
    val humidity: Int? = null,

    @SerializedName("dew_point")
    val dewPoint: Float? = null,

    @SerializedName("clouds")
    val clouds: Int? = null,

    @SerializedName("visibility")
    val visibility: Int? = null,

    @SerializedName("wind_speed")
    val windSpeed: Float? = null,

    @SerializedName("wind_deg")
    val windDeg: Int? = null,

    @SerializedName("weather")
    val weather: List<RawWeather>? = null,

    @SerializedName("pop")
    val pop: Float? = null,

    @SerializedName("snow")
    val snow: Float? = null,

    @SerializedName("rain")
    val rain: Float? = null
)

{

    fun toHourlyWeatherCondition(): HourlyWeatherCondition {
        return HourlyWeatherCondition(
            dt,
            temp,
            feelsLike,
            pressure,
            humidity,
            windSpeed,
            windDeg,
            weather?.get(0)?.id,
            weather?.get(0)?.main,
            weather?.get(0)?.description,
            weather?.get(0)?.icon,
            pop,
            snow,
            rain
        )
    }

}