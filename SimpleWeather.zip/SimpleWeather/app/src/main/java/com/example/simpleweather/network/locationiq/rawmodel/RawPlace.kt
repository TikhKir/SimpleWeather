package com.example.simpleweather.network.locationiq.rawmodel

import com.example.simpleweather.repository.model.LocationWithCoords
import com.google.gson.annotations.SerializedName


data class RawPlace(
    @SerializedName("place_id")
    val placeId: String? = null,

    @SerializedName("licence")
    val licence: String? = null,

    @SerializedName("osm_type")
    val osmType: String? = null,

    @SerializedName("osm_id")
    val osmId: String? = null,

    @SerializedName("boundingbox")
    val boundingBox: List<String>? = null,

    @SerializedName("lat")
    val lat: Float,

    @SerializedName("lon")
    val lon: Float,

    @SerializedName("display_name")
    val displayName: String,

    @SerializedName("class")
    val _class: String? = null,

    @SerializedName("type")
    val type: String? = null,

    @SerializedName("importance")
    val importance: Float? = null,

    @SerializedName("icon")
    val icon: String? = null,

    @SerializedName("address")
    val rawAddress: RawAddress? = null
)
{

    fun toLocationWithCoords(): LocationWithCoords {
        return LocationWithCoords(
            displayName,
            lat,
            lon,
            rawAddress?.city,
            rawAddress?.county,
            rawAddress?.state,
            rawAddress?.country
        )
    }

}