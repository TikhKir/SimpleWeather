package com.example.simpleweather.local.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "places",
    indices = [Index(value = ["name"], unique = true)]
)
data class PlaceDB(
    @PrimaryKey(autoGenerate = true)
    val placeId: Int,
    val name: String,
    val longitude: Float,
    val latitude: Float
)