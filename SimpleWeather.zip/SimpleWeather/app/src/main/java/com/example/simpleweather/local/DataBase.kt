package com.example.simpleweather.local

import androidx.room.Database
import com.example.simpleweather.local.model.DailyWeatherConditionDB
import com.example.simpleweather.local.model.HourlyWeatherConditionDB
import com.example.simpleweather.local.model.PlaceDB

@Database(
    entities = [
        PlaceDB::class,
        DailyWeatherConditionDB::class,
        HourlyWeatherConditionDB::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DataBase {

    companion object {
        const val DB_NAME = "simpleWeather.db"
    }

    abstract fun weatherDao(): WeatherDao
}