package com.example.simpleweather.local

import androidx.room.Dao

@Dao
interface WeatherDao {



}