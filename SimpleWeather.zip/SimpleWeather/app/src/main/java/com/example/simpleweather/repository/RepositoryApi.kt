package com.example.simpleweather.repository

interface RepositoryApi {
}