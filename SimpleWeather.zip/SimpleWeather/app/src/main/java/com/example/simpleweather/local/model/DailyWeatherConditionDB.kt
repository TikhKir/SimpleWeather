package com.example.simpleweather.local.model

import androidx.room.*
import androidx.room.ForeignKey.CASCADE

@Entity(
    tableName = "daily_weather_conditions",
    indices = [Index(value = ["timeStamp"], unique = true)],
    foreignKeys = [
        ForeignKey(
            entity = PlaceDB::class,
            parentColumns = ["placeId"],
            childColumns = ["placeParentId"],
            onDelete = CASCADE
        )
    ]
)
data class DailyWeatherConditionDB(
    @PrimaryKey(autoGenerate = true)
    val dailyConditionId: Int,

    val placeParentId: Int,
    val timeStamp: Int,

    val temp: Float?,
    val tempFeelsLike: Float?,
    val pressure: Int?,
    val humidity: Int?,
    val windSpeed: Float?,
    val windDeg: Int?,

    val weatherId: Int?,
    val weatherName: String?,
    val weatherDescription: String?,
    val weatherIcon: String?,

    val probabilityOfPrecipitation: Float?,
    val snowVolume: Float?,
    val rainVolume: Float?,
    val uvi: Float?
)