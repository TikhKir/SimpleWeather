package com.example.simpleweather.repository.model

data class LocationWithCoords(
    val fullAddress: String,
    val latitude: Float,
    val longitude: Float,
    val addressCity: String?,
    val addressCounty: String?,
    val addressState: String?,
    val addressCountry: String?,
)