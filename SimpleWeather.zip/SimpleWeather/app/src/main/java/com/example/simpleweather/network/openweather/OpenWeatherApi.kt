package com.example.simpleweather.network.openweather

interface OpenWeatherApi {
}